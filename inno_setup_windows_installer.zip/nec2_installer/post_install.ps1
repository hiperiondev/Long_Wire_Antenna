# NEC2 Antenna Length Optimizer — Post-Install Setup
# Called by Inno Setup after file extraction
# All output goes to setup_log.txt in the install dir

param(
    [string]$InstallDir = $PSScriptRoot
)

$LogFile = Join-Path $InstallDir "setup_log.txt"
# Start fresh log on each run
if (Test-Path $LogFile) { Remove-Item $LogFile -Force }

function Log($msg) {
    $ts = Get-Date -Format "HH:mm:ss"
    "$ts  $msg" | Tee-Object -FilePath $LogFile -Append | Out-Null
    Write-Host "$ts  $msg"
}

function ExitOnError($step) {
    if ($LASTEXITCODE -ne 0) {
        Log "ERROR: $step failed (exit code $LASTEXITCODE)"
        exit $LASTEXITCODE
    }
}

Log "=== NEC2 Optimizer post-install setup ==="
Log "Install dir : $InstallDir"
Log "PowerShell  : $($PSVersionTable.PSVersion)"
Log ""

# ── 1. Download Python 3.12 embeddable ──────────────────────────────────────
$PythonDir = Join-Path $InstallDir "python"
$PythonEXE = Join-Path $PythonDir  "python.exe"
$PythonURL = "https://www.python.org/ftp/python/3.12.10/python-3.12.10-embed-amd64.zip"
$PythonZip = Join-Path $InstallDir "python_embed.zip"

if (-not (Test-Path $PythonEXE)) {
    Log "Step 1/5 — Downloading Python 3.12 embeddable (x64) …"
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -Uri $PythonURL -OutFile $PythonZip -UseBasicParsing
    } catch {
        Log "ERROR downloading Python: $_"
        exit 1
    }
    Log "Extracting Python …"
    Expand-Archive -Path $PythonZip -DestinationPath $PythonDir -Force
    Remove-Item $PythonZip -ErrorAction SilentlyContinue
    Log "Python extracted to: $PythonDir"
} else {
    Log "Step 1/5 — Python already present, skipping download."
}

# ── 2. Enable site-packages in the embedded Python ──────────────────────────
#   The embedded zip ships with a python312._pth that has "#import site"
#   commented out.  Pip and installed packages are invisible until we fix it.
Log ""
Log "Step 2/5 — Configuring embedded Python …"

$PthFile = Get-ChildItem -Path $PythonDir -Filter "python*._pth" | Select-Object -First 1
if ($PthFile) {
    $content = Get-Content $PthFile.FullName -Raw
    $changed = $false

    if ($content -match "#import site") {
        $content = $content -replace "#import site", "import site"
        $changed = $true
        Log "  Enabled 'import site' in $($PthFile.Name)"
    }

    # Add Lib\site-packages so installed packages are on sys.path
    $SitePackagesRel = "Lib\site-packages"
    if ($content -notmatch [regex]::Escape($SitePackagesRel)) {
        $content = $content.TrimEnd() + "`r`n$SitePackagesRel`r`n"
        $changed = $true
        Log "  Added '$SitePackagesRel' to $($PthFile.Name)"
    }

    if ($changed) {
        Set-Content -Path $PthFile.FullName -Value $content -NoNewline
    }
} else {
    Log "  WARNING: ._pth file not found — pip may not work correctly."
}

# ── 3. Install pip ───────────────────────────────────────────────────────────
Log ""
Log "Step 3/5 — Installing pip …"

$PipEXE    = Join-Path $PythonDir "Scripts\pip.exe"
$GetPipURL = "https://bootstrap.pypa.io/get-pip.py"
$GetPipPy  = Join-Path $InstallDir "get-pip.py"

if (-not (Test-Path $PipEXE)) {
    try {
        Invoke-WebRequest -Uri $GetPipURL -OutFile $GetPipPy -UseBasicParsing
    } catch {
        Log "ERROR downloading get-pip.py: $_"
        exit 1
    }
    & $PythonEXE $GetPipPy --no-warn-script-location 2>&1 | ForEach-Object { Log "  $_" }
    ExitOnError "pip installation"
    Remove-Item $GetPipPy -ErrorAction SilentlyContinue
    Log "  pip installed successfully."
} else {
    Log "  pip already present, skipping."
}

# Upgrade pip itself
& $PipEXE install --upgrade pip --no-warn-script-location 2>&1 | ForEach-Object { Log "  $_" }

# ── 4. Install Python packages ───────────────────────────────────────────────
Log ""
Log "Step 4/5 — Installing Python packages …"

$Packages = @(
    "tabulate",
    "colorama",
    "matplotlib",
    "reportlab",
    "Pillow"
)

foreach ($pkg in $Packages) {
    Log "  Installing $pkg …"
    & $PipEXE install --upgrade --no-warn-script-location $pkg 2>&1 | ForEach-Object { Log "    $_" }
    ExitOnError "install $pkg"
    Log "  $pkg — OK"
}

# ── 5. Download OpenNEC v2.1.b3 pre-built Windows binary ────────────────────
Log ""
Log "Step 5/5 — Installing OpenNEC (NEC2 simulation engine) …"

$OpenNECDir = Join-Path $InstallDir "OpenNEC"
$OnecEXE    = Join-Path $OpenNECDir "onec.exe"

if (-not (Test-Path $OnecEXE)) {
    $OpenNECURL = "https://github.com/maurymarkowitz/OpenNEC/releases/download/v.2.1.b3/onec-windows-x86_64.zip"
    $OpenNECZip = Join-Path $InstallDir "onec-windows-x86_64.zip"

    Log "  Downloading OpenNEC v2.1.b3 (Windows x86_64) …"
    Log "  URL: $OpenNECURL"

    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -Uri $OpenNECURL -OutFile $OpenNECZip -UseBasicParsing
    } catch {
        Log "  ERROR downloading OpenNEC: $_"
        Log "  The optimizer will run in empirical mode."
        Log "  You can install OpenNEC later from:"
        Log "  https://github.com/maurymarkowitz/OpenNEC/releases"
        # Non-fatal — continue without NEC2
        goto SetupVBS
    }

    Log "  Extracting OpenNEC …"
    if (-not (Test-Path $OpenNECDir)) {
        New-Item -ItemType Directory -Path $OpenNECDir | Out-Null
    }
    Expand-Archive -Path $OpenNECZip -DestinationPath $OpenNECDir -Force
    Remove-Item $OpenNECZip -ErrorAction SilentlyContinue

    # The ZIP may place onec.exe directly or inside a sub-folder
    if (-not (Test-Path $OnecEXE)) {
        $Found = Get-ChildItem -Path $OpenNECDir -Filter "onec.exe" -Recurse -ErrorAction SilentlyContinue |
                 Select-Object -First 1
        if ($Found) {
            if ($Found.DirectoryName -ne $OpenNECDir) {
                Log "  Moving onec.exe from sub-folder to $OpenNECDir …"
                Copy-Item $Found.FullName $OnecEXE -Force
            }
            Log "  onec.exe found: $($Found.FullName)"
        } else {
            Log "  WARNING: onec.exe not found after extraction."
            Log "  Contents of OpenNEC dir:"
            Get-ChildItem -Path $OpenNECDir -Recurse | ForEach-Object { Log "    $($_.FullName)" }
        }
    } else {
        Log "  onec.exe ready: $OnecEXE"
    }
} else {
    Log "  OpenNEC already present: $OnecEXE"
}

:SetupVBS

# ── 6. Set NEC2C machine-wide environment variable ───────────────────────────
Log ""
if (Test-Path $OnecEXE) {
    [System.Environment]::SetEnvironmentVariable("NEC2C", $OnecEXE, "Machine")
    Log "NEC2C environment variable set: $OnecEXE  (machine-wide)"
} else {
    Log "NEC2C environment variable NOT set (onec.exe not found)."
    Log "Empirical mode will be used until onec.exe is provided."
}

# ── 7. Write VBScript GUI launcher (no console window) ───────────────────────
Log ""
Log "Writing GUI launcher (launch_gui.vbs) …"

$VBSPath = Join-Path $InstallDir "launch_gui.vbs"

# Use escaped paths in the VBS string
$PyEXE  = (Join-Path $PythonDir "python.exe").Replace("\", "\\")
$Script = (Join-Path $InstallDir "nec2_length_optimizer.py").Replace("\", "\\")
$WorkDir = $InstallDir.Replace("\", "\\")

$VBSContent = @"
' NEC2 Antenna Length Optimizer — GUI launcher (no console window)
Set WshShell = CreateObject("WScript.Shell")
WshShell.CurrentDirectory = "$WorkDir"
WshShell.Run """$PyEXE"" ""$Script"" --gui", 0, False
"@

Set-Content -Path $VBSPath -Value $VBSContent -Encoding UTF8
Log "VBS launcher written: $VBSPath"

# ── Done ──────────────────────────────────────────────────────────────────────
Log ""
Log "============================================================"
Log "  Setup complete!"
Log "  Python  : $PythonEXE"
if (Test-Path $OnecEXE) {
    Log "  OpenNEC : $OnecEXE"
    Log "  NEC2C   : (env variable set)"
} else {
    Log "  OpenNEC : NOT found — empirical mode active"
}
Log "  Launcher: $VBSPath"
Log "============================================================"
exit 0
