"""
generate_icon.py  -  Create a simple antenna-themed ICO file for the installer.
Run this script on Linux/Windows to produce nec2_optimizer.ico.
Requires Pillow: pip install Pillow
"""
import struct
import zlib
import io
import os

try:
    from PIL import Image, ImageDraw, ImageFont
    HAS_PIL = True
except ImportError:
    HAS_PIL = False


def make_icon_pil(sizes=(256, 128, 64, 48, 32, 16)):
    """Generate antenna-themed icon using Pillow and save as .ico"""
    frames = []
    for size in sizes:
        img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        d   = ImageDraw.Draw(img)

        # Background circle
        margin = max(1, size // 12)
        d.ellipse([margin, margin, size - margin, size - margin],
                  fill=(30, 80, 160, 255))

        cx = size // 2
        cy = size // 2

        # Vertical antenna mast
        mast_w  = max(2, size // 18)
        mast_h  = int(size * 0.55)
        d.rectangle([cx - mast_w, cy - mast_h + size // 6,
                     cx + mast_w, cy + size // 6],
                    fill=(220, 220, 255, 255))

        # Feed point dot
        dot_r = max(3, size // 10)
        d.ellipse([cx - dot_r, cy - dot_r, cx + dot_r, cy + dot_r],
                  fill=(255, 200, 50, 255))

        # Radiating wire (angled up-right)
        wire_w = max(2, size // 20)
        end_x  = cx + int(size * 0.38)
        end_y  = cy - mast_h + size // 5
        for off in range(-wire_w // 2, wire_w // 2 + 1):
            d.line([(cx, cy + off), (end_x, end_y + off)],
                   fill=(100, 220, 255, 255), width=wire_w)

        # Counterpoise (angled down-left)
        cp_x = cx - int(size * 0.28)
        cp_y = cy + int(size * 0.18)
        for off in range(-wire_w // 2, wire_w // 2 + 1):
            d.line([(cx, cy + off), (cp_x, cp_y + off)],
                   fill=(255, 160, 60, 255), width=wire_w)

        # Ground line
        gw = max(1, size // 22)
        gy = cy + size // 5
        d.line([(cx - size // 5, gy), (cx + size // 5, gy)],
               fill=(180, 200, 180, 255), width=gw)
        for i in range(3):
            sx = cx - size // 8 + i * (size // 8)
            d.line([(sx, gy), (sx - size // 20, gy + size // 14)],
                   fill=(180, 200, 180, 255), width=gw)

        frames.append(img)
    return frames


def save_ico(frames, path):
    """Save a list of PIL RGBA images as a .ico file."""
    ico_frames = []
    for img in frames:
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        ico_frames.append((img.size[0], img.size[1], buf.getvalue()))

    # ICO header
    header  = struct.pack("<HHH", 0, 1, len(ico_frames))
    offset  = 6 + len(ico_frames) * 16
    entries = b""
    data    = b""
    for w, h, png_data in ico_frames:
        entries += struct.pack("<BBBBHHII",
                               0 if w >= 256 else w,
                               0 if h >= 256 else h,
                               0, 0, 1, 32,
                               len(png_data), offset)
        offset += len(png_data)
        data   += png_data
    with open(path, "wb") as f:
        f.write(header + entries + data)
    print(f"Icon saved: {path}")


def make_minimal_ico(path):
    """Fallback: create a minimal valid 16x16 ICO with no Pillow."""
    # 16x16 single-colour blue ICO (BMP format inside ICO)
    w = h = 16
    # BITMAPINFOHEADER
    bih = struct.pack("<IiiHHIIiiII",
                      40,       # biSize
                      w, h * 2, # width, height (×2 for AND+XOR masks in ICO)
                      1,        # planes
                      32,       # biBitCount
                      0,        # biCompression
                      w * h * 4 + w * h // 8,
                      0, 0, 0, 0)
    # Pixel data: BGRA, 16x16 = 256 pixels, dark blue
    pixels = b"\x80\x30\x10\xff" * (w * h)  # BGRA: R=16, G=48, B=128
    # AND mask: 16 bytes (1 bit per pixel, all 0 = opaque)
    and_mask = b"\x00" * (w * h // 8)
    bmp_data  = bih + pixels + and_mask

    header  = struct.pack("<HHH", 0, 1, 1)
    entry   = struct.pack("<BBBBHHII", w, h, 0, 0, 1, 32, len(bmp_data), 6 + 16)
    with open(path, "wb") as f:
        f.write(header + entry + bmp_data)
    print(f"Minimal fallback icon saved: {path}")


if __name__ == "__main__":
    out = os.path.join(os.path.dirname(__file__), "nec2_optimizer.ico")
    if HAS_PIL:
        frames = make_icon_pil()
        save_ico(frames, out)
    else:
        make_minimal_ico(out)
