"""
post_install_setup.py  —  run during Inno Setup [Run] section
Installs all required Python packages into the embedded Python environment.
"""
import subprocess
import sys
import os

PYTHON = os.path.join(os.path.dirname(sys.executable), "python.exe")
BASE   = os.path.dirname(sys.executable)

packages = [
    "pip",
    "tabulate",
    "colorama",
    "matplotlib",
    "reportlab",
    "Pillow",
]

def main():
    # Ensure pip is available
    subprocess.check_call([PYTHON, "-m", "ensurepip", "--upgrade"])
    # Upgrade pip itself
    subprocess.check_call([PYTHON, "-m", "pip", "install", "--upgrade", "pip"])
    # Install packages
    for pkg in packages:
        subprocess.check_call([PYTHON, "-m", "pip", "install", "--upgrade", pkg])

if __name__ == "__main__":
    main()
