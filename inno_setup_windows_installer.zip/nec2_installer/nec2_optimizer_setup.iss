; =============================================================================
;  NEC2 Antenna Length Optimizer — Full Windows Installer
;  Inno Setup 6.x  (https://jrsoftware.org/isinfo.php)
;
;  What this installer does:
;    1. Extracts the optimizer script and all helper files
;    2. Downloads Python 3.12 embeddable (x64) + installs pip
;    3. Installs Python packages: tabulate, colorama, matplotlib, reportlab, Pillow
;    4. Clones / downloads OpenNEC (https://github.com/maurymarkowitz/OpenNEC)
;    5. Sets the NEC2C environment variable pointing to onec.exe (if found)
;    6. Creates a Desktop shortcut that launches the GUI (no console window)
;
;  Build instructions:
;    1. Install Inno Setup 6:  https://jrsoftware.org/isdl.php
;    2. Open this .iss file in the Inno Setup IDE (or Compil32.exe)
;    3. Press F9 to compile — the output EXE appears in Output\
;
;  Directory layout expected BEFORE compiling
;  (all files must live in the same folder as this .iss):
;
;    nec2_optimizer_setup.iss         ← this file
;    nec2_length_optimizer.py         ← main script
;    post_install.ps1                 ← PowerShell post-install worker
;    nec2_optimizer.ico               ← application icon (PNG-inside-ICO)
;    launch_optimizer.bat             ← optional CLI launcher
;
; =============================================================================

#define MyAppName      "NEC2 Antenna Length Optimizer"
#define MyAppVersion   "1.0"
#define MyAppPublisher "LU3VEA"
#define MyAppURL       "https://github.com/maurymarkowitz/OpenNEC"
#define MyAppExeName   "launch_gui.vbs"
#define MySetupName    "NEC2_Optimizer_Setup"

[Setup]
AppId={{A7C3F821-9B2D-4E5F-8C1A-D6B0E3F92847}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL={#MyAppURL}
AppSupportURL={#MyAppURL}
AppUpdatesURL={#MyAppURL}
DefaultDirName={autopf}\NEC2_Optimizer
DefaultGroupName={#MyAppName}
AllowNoIcons=yes
; Require admin so we can set machine-wide env variables and install to Program Files
PrivilegesRequired=admin
OutputDir=Output
OutputBaseFilename={#MySetupName}
SetupIconFile=nec2_optimizer.ico
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
; Minimum Windows 10 (PowerShell 5.1 required for Expand-Archive)
MinVersion=10.0
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
UninstallDisplayIcon={app}\nec2_optimizer.ico
UninstallDisplayName={#MyAppName}
; Show a ReadyMemo telling user what will happen (internet required)
DisableReadyPage=no
; Log file placed in AppData
SetupLogging=yes

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Messages]
; Custom messages
WelcomeLabel2=This will install [name/ver] on your computer.%n%n\
The installer will:%n\
  1. Copy the NEC2 Optimizer script to your computer%n\
  2. Download Python 3.12 (embedded, self-contained)%n\
  3. Install required Python packages (tabulate, colorama, matplotlib, reportlab, Pillow)%n\
  4. Download OpenNEC v2.1.b3 pre-built binary (onec-windows-x86_64.zip)%n\
  5. Set the NEC2C environment variable automatically%n\
  6. Create a Desktop shortcut to launch the GUI%n%n\
An internet connection is required for steps 2-4.%n\
Click Next to continue.
FinishedHeadingLabel=Installation complete
FinishedLabel=The {#MyAppName} has been installed on your computer.%n%n\
A shortcut has been added to your Desktop and Start Menu.%n\
If OpenNEC (onec.exe) was found or built, the NEC2C environment%n\
variable has been set automatically.%n%n\
Click Finish to close the installer.

[Tasks]
Name: "desktopicon";    Description: "{cm:CreateDesktopIcon}";   GroupDescription: "{cm:AdditionalIcons}"; Flags: checkedonce
Name: "startmenuicon";  Description: "Create a &Start Menu shortcut"; GroupDescription: "{cm:AdditionalIcons}"; Flags: checkedonce

[Files]
; ── Core application files ──────────────────────────────────────────────────
Source: "nec2_length_optimizer.py";    DestDir: "{app}"; Flags: ignoreversion
Source: "post_install.ps1";             DestDir: "{app}"; Flags: ignoreversion
Source: "launch_optimizer.bat";         DestDir: "{app}"; Flags: ignoreversion
Source: "nec2_optimizer.ico";           DestDir: "{app}"; Flags: ignoreversion

; ── README stub (generated below via [Code] section) ───────────────────────
; (no additional binary dependencies bundled — everything is downloaded)

[Icons]
; Desktop shortcut — runs VBScript launcher (no console window)
Name: "{autodesktop}\{#MyAppName}";         \
      Filename: "{sys}\wscript.exe";         \
      Parameters: """{app}\launch_gui.vbs"""; \
      WorkingDir: "{app}";                   \
      IconFilename: "{app}\nec2_optimizer.ico"; \
      Comment: "Launch NEC2 Antenna Length Optimizer GUI"; \
      Tasks: desktopicon

; Start-menu shortcut
Name: "{group}\{#MyAppName}";               \
      Filename: "{sys}\wscript.exe";         \
      Parameters: """{app}\launch_gui.vbs"""; \
      WorkingDir: "{app}";                   \
      IconFilename: "{app}\nec2_optimizer.ico"; \
      Comment: "Launch NEC2 Antenna Length Optimizer GUI"; \
      Tasks: startmenuicon

; Start-menu CLI launcher (for advanced users)
Name: "{group}\{#MyAppName} (command line)"; \
      Filename: "{app}\launch_optimizer.bat"; \
      WorkingDir: "{app}";                    \
      IconFilename: "{app}\nec2_optimizer.ico"; \
      Tasks: startmenuicon

; Uninstall
Name: "{group}\Uninstall {#MyAppName}"; Filename: "{uninstallexe}"

[Run]
; ── Post-install: run PowerShell script ─────────────────────────────────────
; -ExecutionPolicy Bypass  so the script runs even on locked-down machines
; -WindowStyle Hidden      suppress the PowerShell window during install
; StatusMsg is shown in the Inno Setup progress dialog
Filename: "{sys}\WindowsPowerShell\v1.0\powershell.exe"; \
  Parameters: "-NoProfile -ExecutionPolicy Bypass -WindowStyle Normal -File ""{app}\post_install.ps1"" -InstallDir ""{app}"""; \
  WorkingDir: "{app}"; \
  StatusMsg: "Downloading Python, packages and OpenNEC (may take a few minutes)…"; \
  Flags: runhidden waituntilterminated; \
  Description: "Install Python and dependencies"

[UninstallDelete]
; Remove downloaded/generated files that are not tracked by Inno Setup
Type: filesandordirs; Name: "{app}\python"
Type: filesandordirs; Name: "{app}\OpenNEC"
Type: filesandordirs; Name: "{app}\OpenNEC-main"
Type: files;          Name: "{app}\launch_gui.vbs"
Type: files;          Name: "{app}\setup_log.txt"
Type: files;          Name: "{app}\README.txt"

[Registry]
; Remove machine-wide NEC2C env variable on uninstall
Root: HKLM; Subkey: "SYSTEM\CurrentControlSet\Control\Session Manager\Environment"; \
     ValueType: string; ValueName: "NEC2C"; ValueData: ""; \
     Flags: deletevalue uninsdeletevalue

[Code]
// ─────────────────────────────────────────────────────────────────────────────
// Inno Setup Pascal script — custom install-time actions
// ─────────────────────────────────────────────────────────────────────────────

//
// WriteREADME: create a helpful README.txt inside the install folder.
//
procedure WriteREADME(AppDir: string);
var
  Lines: TArrayOfString;
  i:     Integer;
  Path:  string;
begin
  SetArrayLength(Lines, 40);
  i := 0;
  Lines[i] := 'NEC2 Antenna Length Optimizer'; Inc(i);
  Lines[i] := '=============================='; Inc(i);
  Lines[i] := ''; Inc(i);
  Lines[i] := 'Author  : LU3VEA (CC0 v1.0)'; Inc(i);
  Lines[i] := 'OpenNEC : https://github.com/maurymarkowitz/OpenNEC'; Inc(i);
  Lines[i] := 'Release : v2.1.b3 (onec-windows-x86_64.zip)'; Inc(i);
  Lines[i] := ''; Inc(i);
  Lines[i] := 'QUICK START'; Inc(i);
  Lines[i] := '-----------'; Inc(i);
  Lines[i] := '  Double-click the Desktop shortcut (or Start Menu entry) to open the GUI.'; Inc(i);
  Lines[i] := ''; Inc(i);
  Lines[i] := 'COMMAND LINE'; Inc(i);
  Lines[i] := '------------'; Inc(i);
  Lines[i] := '  Use launch_optimizer.bat for CLI mode, e.g.:'; Inc(i);
  Lines[i] := '    launch_optimizer.bat --csv my_bands.csv --cp-angle 90 --unun 9'; Inc(i);
  Lines[i] := ''; Inc(i);
  Lines[i] := 'OPENNEC / NEC2 ENGINE'; Inc(i);
  Lines[i] := '---------------------'; Inc(i);
  Lines[i] := '  OpenNEC v2.1.b3 pre-built binary (onec.exe) is installed in:'; Inc(i);
  Lines[i] := '    ' + AppDir + '\OpenNEC\onec.exe'; Inc(i);
  Lines[i] := '  The NEC2C environment variable is set automatically during install.'; Inc(i);
  Lines[i] := '  NEC2 simulation mode is enabled by default.'; Inc(i);
  Lines[i] := ''; Inc(i);
  Lines[i] := '  If NEC2C is not detected, the optimizer falls back to empirical mode.'; Inc(i);
  Lines[i] := '  Check setup_log.txt for details.'; Inc(i);
  Lines[i] := ''; Inc(i);
  Lines[i] := 'PYTHON PACKAGES INSTALLED'; Inc(i);
  Lines[i] := '-------------------------'; Inc(i);
  Lines[i] := '  tabulate, colorama, matplotlib, reportlab, Pillow'; Inc(i);
  Lines[i] := '  (installed into: ' + AppDir + '\python)'; Inc(i);
  Lines[i] := ''; Inc(i);
  Lines[i] := 'SETUP LOG'; Inc(i);
  Lines[i] := '---------'; Inc(i);
  Lines[i] := '  See setup_log.txt in this directory for full installation details.'; Inc(i);
  Lines[i] := ''; Inc(i);
  Lines[i] := 'UNINSTALL'; Inc(i);
  Lines[i] := '---------'; Inc(i);
  Lines[i] := '  Use Windows Settings > Apps, or the Start Menu uninstall entry.'; Inc(i);

  SetArrayLength(Lines, i);
  Path := AppDir + '\README.txt';
  SaveStringsToFile(Path, Lines, False);
end;

//
// CurStepChanged: called by Inno Setup at each install phase.
//   ssPostInstall — everything is copied; run our README writer here
//                   (the PowerShell [Run] step fires AFTER this).
//
procedure CurStepChanged(CurStep: TSetupStep);
begin
  if CurStep = ssPostInstall then
  begin
    WriteREADME(ExpandConstant('{app}'));
  end;
end;

//
// NextButtonClick: block proceeding from the Welcome page if we detect
// no internet (simple connectivity probe via PowerShell).
// This is advisory only — the real download happens in [Run].
//
function NextButtonClick(CurPageID: Integer): Boolean;
var
  ResultCode: Integer;
begin
  Result := True;
  // Page 1 = wpWelcome
  if CurPageID = wpWelcome then
  begin
    // Quick connectivity check: try to reach python.org
    Exec(ExpandConstant('{sys}\WindowsPowerShell\v1.0\powershell.exe'),
         '-NoProfile -ExecutionPolicy Bypass -Command ' +
         '"try { $r = Invoke-WebRequest -Uri https://www.python.org -UseBasicParsing -TimeoutSec 5; exit 0 } catch { exit 1 }"',
         '', SW_HIDE, ewWaitUntilTerminated, ResultCode);
    if ResultCode <> 0 then
    begin
      if MsgBox('An internet connection could not be confirmed (python.org unreachable).' + #13#10 +
                'Python and the required packages will be downloaded during installation.' + #13#10 + #13#10 +
                'Do you want to continue anyway?',
                mbConfirmation, MB_YESNO) = IDNO then
        Result := False;
    end;
  end;
end;

//
// InitializeSetup: check that we are on a 64-bit Windows 10 or newer.
//
function InitializeSetup(): Boolean;
begin
  Result := True;
  if not IsWin64 then
  begin
    MsgBox('This installer requires a 64-bit version of Windows 10 or later.', mbError, MB_OK);
    Result := False;
  end;
end;
