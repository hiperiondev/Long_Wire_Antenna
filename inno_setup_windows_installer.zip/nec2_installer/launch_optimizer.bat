@echo off
REM NEC2 Antenna Length Optimizer - GUI Launcher
REM This file is placed in the installation directory

cd /d "%~dp0"
"%~dp0python\python.exe" "%~dp0nec2_length_optimizer.py" --gui %*
