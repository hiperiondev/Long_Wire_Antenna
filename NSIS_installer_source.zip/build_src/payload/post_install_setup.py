#!/usr/bin/env python3
"""
post_install_setup.py
======================
Run once by the NSIS installer (using the just-installed Python interpreter)
to finish setting up the NEC2 Antenna Length Optimizer:

  1. Installs required/optional Python packages via pip:
       matplotlib, numpy, tabulate, colorama, reportlab
  2. Downloads the latest OpenNEC (nec2c) Windows release
     (onec-windows-x86_64.zip) from the OpenNEC GitHub repo and
     extracts nec2c.exe into the install directory.

Usage:
    python post_install_setup.py "<INSTALL_DIR>"

Exit codes:
    0  = success (script will still continue even if optional pieces fail)
    1  = fatal error
"""

import os
import sys
import json
import zipfile
import shutil
import subprocess
import urllib.request
import tempfile

GITHUB_API_RELEASES = "https://api.github.com/repos/maurymarkowitz/OpenNEC/releases/latest"
ASSET_NAME = "onec-windows-x86_64.zip"
NEC2C_EXE_NAMES = (
    "nec2c.exe", "onec.exe",
    "onec-windows-x86_64.exe", "onec_windows_x86_64.exe",
    "nec2c-mpich.exe", "xnec2c.exe",
)


def log(msg):
    print(msg, flush=True)


def pip_install(packages):
    log(f"[*] Installing Python packages: {', '.join(packages)}")
    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "--upgrade", "--no-warn-script-location", *packages],
            check=True,
        )
        return True
    except subprocess.CalledProcessError as e:
        log(f"[!] pip install failed (exit code {e.returncode}) for: {', '.join(packages)}")
        return False


def fetch_latest_onec_url():
    """Query GitHub API for the latest OpenNEC release asset URL."""
    log("[*] Querying GitHub for latest OpenNEC release...")
    req = urllib.request.Request(
        GITHUB_API_RELEASES,
        headers={"User-Agent": "nec2-length-optimizer-installer", "Accept": "application/vnd.github+json"},
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        data = json.load(resp)

    for asset in data.get("assets", []):
        if asset.get("name", "").lower() == ASSET_NAME.lower():
            return asset["browser_download_url"], asset["name"]

    # Fallback: any asset containing "windows" and ".zip"
    for asset in data.get("assets", []):
        name = asset.get("name", "").lower()
        if "windows" in name and name.endswith(".zip"):
            return asset["browser_download_url"], asset["name"]

    raise RuntimeError("Could not find a Windows release asset in the latest OpenNEC release.")


def download_file(url, dest_path):
    log(f"[*] Downloading: {url}")
    req = urllib.request.Request(url, headers={"User-Agent": "nec2-length-optimizer-installer"})
    with urllib.request.urlopen(req, timeout=120) as resp, open(dest_path, "wb") as out:
        total = int(resp.headers.get("Content-Length", 0))
        downloaded = 0
        chunk = 65536
        while True:
            buf = resp.read(chunk)
            if not buf:
                break
            out.write(buf)
            downloaded += len(buf)
            if total:
                pct = downloaded * 100 // total
                print(f"\r    {downloaded//1024} KB / {total//1024} KB ({pct}%)", end="", flush=True)
    print()


def install_opennec(install_dir):
    """Download, extract, and normalize the latest OpenNEC Windows release.

    The OpenNEC release zip layout can vary (binary at top level, or nested
    inside a subfolder). To make discovery reliable regardless of layout,
    this function:
      1. Extracts the zip into <install_dir>\\nec2c\\_extracted\\
      2. Recursively locates the nec2c/onec executable
      3. Copies it to a FIXED, known location: <install_dir>\\nec2c\\onec.exe
      4. Also copies it to C:\\Program Files\\OpenNEC\\onec.exe, which is
         one of nec2_length_optimizer.py's hard-coded NEC2C_SEARCH_PATHS,
         so the script finds it automatically even without --gui / $NEC2C.
    """
    bin_dir = os.path.join(install_dir, "nec2c")
    extract_dir = os.path.join(bin_dir, "_extracted")
    os.makedirs(extract_dir, exist_ok=True)

    try:
        url, asset_name = fetch_latest_onec_url()
    except Exception as e:
        log(f"[!] Failed to query GitHub releases: {e}")
        log("    You can manually download 'onec-windows-x86_64.zip' from:")
        log("    https://github.com/maurymarkowitz/OpenNEC/releases/latest")
        log(f"    and extract onec.exe into: {bin_dir}")
        return None

    with tempfile.TemporaryDirectory() as tmpdir:
        zip_path = os.path.join(tmpdir, asset_name)
        try:
            download_file(url, zip_path)
        except Exception as e:
            log(f"[!] Download failed: {e}")
            return None

        log(f"[*] Extracting {asset_name} ...")
        try:
            with zipfile.ZipFile(zip_path, "r") as zf:
                zf.extractall(extract_dir)
        except Exception as e:
            log(f"[!] Extraction failed: {e}")
            return None

    # Recursively locate the nec2/onec executable, wherever it landed.
    candidates = []
    for root, _dirs, files in os.walk(extract_dir):
        for f in files:
            if f.lower() in NEC2C_EXE_NAMES:
                candidates.append(os.path.join(root, f))

    if not candidates:
        log("[!] Could not locate onec.exe / nec2c.exe inside the OpenNEC archive.")
        log(f"    Check contents of: {extract_dir}")
        return None

    # Prefer 'onec.exe' over 'nec2c.exe' if both exist (OpenNEC naming).
    candidates.sort(key=lambda p: 0 if os.path.basename(p).lower().startswith("onec") else 1)
    src = candidates[0]
    log(f"[*] Found engine binary: {src}")

    # 1) Copy to a fixed, known location used by run_gui.bat / $NEC2C
    fixed_path = os.path.join(bin_dir, "onec.exe")
    try:
        shutil.copy2(src, fixed_path)
        log(f"[OK] Installed engine to: {fixed_path}")
    except Exception as e:
        log(f"[!] Could not copy engine to {fixed_path}: {e}")
        fixed_path = src  # fall back to the extracted location

    # Copy any DLLs sitting alongside the binary too (some OpenNEC builds
    # ship runtime DLLs next to the .exe).
    src_dir = os.path.dirname(src)
    for f in os.listdir(src_dir):
        if f.lower().endswith(".dll"):
            try:
                shutil.copy2(os.path.join(src_dir, f), os.path.join(bin_dir, f))
            except Exception:
                pass

    # 2) Also place a copy at one of the script's hard-coded
    #    NEC2C_SEARCH_PATHS: C:\Program Files\OpenNEC\onec.exe
    for prog_files_env in ("ProgramFiles", "ProgramFiles(x86)"):
        prog_files = os.environ.get(prog_files_env)
        if not prog_files:
            continue
        target_dir = os.path.join(prog_files, "OpenNEC")
        try:
            os.makedirs(target_dir, exist_ok=True)
            target_path = os.path.join(target_dir, "onec.exe")
            shutil.copy2(fixed_path, target_path)
            for f in os.listdir(bin_dir):
                if f.lower().endswith(".dll"):
                    shutil.copy2(os.path.join(bin_dir, f), os.path.join(target_dir, f))
            log(f"[OK] Also installed engine to: {target_path}")
        except Exception as e:
            log(f"[!] Could not copy engine to {target_dir}: {e}")

    return fixed_path


def write_env_hint(install_dir, nec2c_path):
    """Write a small .bat helper that sets NEC2C env var, for convenience."""
    if not nec2c_path:
        return
    bat_path = os.path.join(install_dir, "set_nec2c_env.bat")
    try:
        with open(bat_path, "w") as f:
            f.write(f'@echo off\r\nset "NEC2C={nec2c_path}"\r\n')
        log(f"[OK] Wrote helper script: {bat_path}")
    except Exception as e:
        log(f"[!] Could not write {bat_path}: {e}")


def main():
    if len(sys.argv) < 2:
        log("Usage: post_install_setup.py <INSTALL_DIR>")
        sys.exit(1)

    install_dir = sys.argv[1]
    os.makedirs(install_dir, exist_ok=True)

    log("=" * 60)
    log(" NEC2 Antenna Length Optimizer - Post-install setup")
    log("=" * 60)

    log("[*] Upgrading pip ...")
    subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "pip"], check=False)

    # Required + optional Python dependencies used by the script
    packages = [
        "numpy",
        "matplotlib",
        "tabulate",
        "colorama",
        "reportlab",
    ]
    pip_install(packages)

    nec2c_path = install_opennec(install_dir)
    write_env_hint(install_dir, nec2c_path)

    log("")
    log("[DONE] Post-install setup finished.")
    # Never fail the overall installer due to optional download issues
    sys.exit(0)


if __name__ == "__main__":
    main()
