; ============================================================================
;  NEC2 Antenna Length Optimizer - Windows Installer
;  Built with NSIS (Nullsoft Scriptable Install System)
;
;  This installer:
;    1. Checks for a Python 3 interpreter; if missing, silently downloads
;       and installs Python 3.12 (64-bit) from python.org with pip + PATH.
;    2. Moves nec2_length_optimizer.py (shipped beside Setup.exe, NOT
;       embedded in this installer) into the install dir, and copies the
;       small helper files (run_gui.bat, post_install_setup.py, icon,
;       license) which ARE embedded as usual.
;    3. Installs a statically-linked onec.exe (the OpenNEC / NEC2 engine,
;       built from source with NO MinGW runtime DLL dependencies at all)
;       into $INSTDIR\nec2c\ and C:\Program Files\OpenNEC\ (and the (x86)
;       variant). This is bundled directly inside this installer, so no
;       internet access is needed for onec.exe to run.
;    4. Runs a post-install script that:
;         - pip-installs: numpy, matplotlib, tabulate, colorama, reportlab
;         - optionally tries to download the latest official OpenNEC
;           Windows release as an upgrade; verifies it actually starts
;           and falls back to the bundled static binary if not.
;    5. Creates a Desktop shortcut that launches:
;           nec2_length_optimizer.py --gui
;    6. Registers an uninstaller.
;
;  Build:
;     makensis nec2_optimizer_installer.nsi
;
;  Fix history (older approaches, superseded by v1.0.4 below):
;    - v1.0.1/1.0.2: onec.exe missing libwinpthread-1.dll /
;      libgcc_s_seh-1.dll / libstdc++-6.dll - tried bundling /
;      downloading matching MinGW-w64 runtime DLLs.
;    - v1.0.3: onec.exe fails with
;        "The procedure entry point clock_gettime64 could not be located
;         in the dynamic link library ...\libstdc++-6.dll"
;      Tried bumping the bundled/downloaded runtime DLLs to GCC 15.2.0.
;      This did NOT fix it: clock_gettime64 is referenced by official
;      OpenNEC v2.1.0+ Windows builds (GCC 15.x/16.x MinGW-w64 toolchain)
;      but is NOT exported by ANY current MinGW-w64 GCC 15.x/16.x runtime
;      DLL - this is an unresolved upstream toolchain bug (see
;      msys2/MINGW-packages#24355, #27465 and
;      niXman/mingw-builds-binaries#112). No combination of "matching"
;      runtime DLLs can fix it.
;
;  Fix (2026-06, v1.0.4): bundle a statically-linked onec.exe
;     Built directly from the OpenNEC source (BACKEND=original, fully
;     static: -static -static-libgcc -static-libstdc++ -lwinpthread),
;     this onec.exe has NO MinGW runtime DLL dependencies whatsoever -
;     `objdump -p onec.exe` shows only KERNEL32.dll and msvcrt.dll, both
;     present on every Windows version. This completely sidesteps the
;     clock_gettime64 issue (and the libwinpthread/libgcc_s_seh/libstdc++
;     issues before it), with zero network access required.
;
;     This binary (payload\bin\onec.exe, ~530 KB stripped) is installed
;     to BOTH:
;       - $INSTDIR\nec2c\onec.exe          (primary engine location, also
;                                            kept as nec2c\onec_bundled.exe
;                                            for self-repair)
;       - C:\Program Files\OpenNEC\onec.exe        (hard-coded search path)
;       - C:\Program Files (x86)\OpenNEC\onec.exe  (hard-coded search path)
;
;     post_install_setup.py then OPTIONALLY tries to fetch a newer
;     official OpenNEC release as an upgrade (it may be faster, e.g. an
;     OpenBLAS build), but verify_onec() actually test-runs it first and
;     keeps/restores the bundled static binary if the official build
;     doesn't start (e.g. it hits clock_gettime64). repair_existing_engine()
;     does the same self-repair on an already-installed onec.exe -- so
;     simply re-running this Setup.exe fixes a machine that hit this
;     error, with no internet access required at all.
;
;  Fix (2026-06, v1.0.5): bundle MinGW-w64 runtime DLLs as a fallback
;     The bundled onec.exe itself (above) is fully static and needs none
;     of this, but the OPTIONAL official-release upgrade path in
;     post_install_setup.py (_try_download_official_release) downloads a
;     dynamically-linked onec.exe from upstream that DOES typically need
;     libwinpthread-1.dll / libgcc_s_seh-1.dll / libstdc++-6.dll. If those
;     are missing, Windows reports "...The code execution cannot proceed
;     because libwinpthread-1.dll was not found...".
;
;     To prevent this, this section now also installs matching x86_64
;     MinGW-w64 runtime DLLs (payload\bin\*.dll) alongside onec.exe in
;     every install location ($INSTDIR\nec2c, Program Files\OpenNEC, and
;     the (x86) variant). Windows resolves DLL imports from the
;     executable's own directory first, so any onec.exe placed in these
;     folders - bundled static, official download, or a future build -
;     will find these runtime DLLs right next to it if it needs them.
;     This is in addition to (not a replacement for) the static
;     onec.exe fix above, which remains the guaranteed-working baseline.
;
;  Change (2026-06, v1.0.6): onec.exe / onec_dynamic.exe final naming
;     post_install_setup.py's install_opennec() now finishes by renaming
;     whatever ended up at $INSTDIR\nec2c\onec.exe (the static baseline,
;     or a verified official-release upgrade) to
;     $INSTDIR\nec2c\onec_dynamic.exe, and renaming the static
;     $INSTDIR\nec2c\onec_bundled.exe back to $INSTDIR\nec2c\onec.exe.
;
;     This guarantees that $INSTDIR\nec2c\onec.exe - the name run_gui.bat,
;     nec2_length_optimizer.py, and the Program Files\OpenNEC mirrors all
;     look for - is ALWAYS the dependency-free static build, while any
;     downloaded official/dynamic build is kept alongside as
;     onec_dynamic.exe for optional manual use. This section (SecEngine)
;     is unaffected: it still extracts onec.exe + onec_bundled.exe fresh
;     on every run, so re-running this Setup.exe always restores a clean
;     starting point for that finalize step.
;
;  Change (2026-06): nec2_length_optimizer.py is no longer embedded
;     The main application script is no longer compressed/embedded inside
;     this installer via a File directive.  Instead it ships as a loose
;     .py file placed in the SAME FOLDER as Setup.exe ($EXEDIR), and the
;     installer MOVES it into $INSTDIR during "Application Files".
;
;     Distribute this installer as:
;       SomeFolder\
;         NEC2_Length_Optimizer_Setup.exe
;         nec2_length_optimizer.py
; ============================================================================

!include "MUI2.nsh"
!include "LogicLib.nsh"
!include "FileFunc.nsh"
!include "x64.nsh"

; ---------------------------------------------------------------------------
; General configuration
; ---------------------------------------------------------------------------
!define APP_NAME        "NEC2 Antenna Length Optimizer"
!define APP_VERSION     "1.0.6"
!define APP_PUBLISHER   "LU3VEA"
!define APP_EXE_SCRIPT  "nec2_length_optimizer.py"
!define APP_LAUNCHER    "run_gui.bat"
!define UNINST_KEY      "Software\Microsoft\Windows\CurrentVersion\Uninstall\NEC2LengthOptimizer"

; Python installer to fetch if Python is not found (64-bit, official python.org)
!define PYTHON_VERSION    "3.12.7"
!define PYTHON_INSTALLER  "python-${PYTHON_VERSION}-amd64.exe"
!define PYTHON_URL          "https://www.python.org/ftp/python/${PYTHON_VERSION}/${PYTHON_INSTALLER}"

Name "${APP_NAME}"
OutFile "NEC2_Length_Optimizer_Setup.exe"
Unicode True
InstallDir "$PROGRAMFILES64\NEC2LengthOptimizer"
InstallDirRegKey HKLM "${UNINST_KEY}" "InstallLocation"
RequestExecutionLevel admin
SetCompressor /SOLID lzma

; ---------------------------------------------------------------------------
; Interface
; ---------------------------------------------------------------------------
!define MUI_ABORTWARNING
!define MUI_ICON   "assets\app.ico"
!define MUI_UNICON "assets\app.ico"

!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_LICENSE "assets\LICENSE.txt"
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!define MUI_FINISHPAGE_RUN "$INSTDIR\${APP_LAUNCHER}"
!define MUI_FINISHPAGE_RUN_TEXT "Launch NEC2 Antenna Length Optimizer now"
!insertmacro MUI_PAGE_FINISH

!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES

!insertmacro MUI_LANGUAGE "English"

; ---------------------------------------------------------------------------
; Helper: detect Python (any version) by querying 'py -3' / 'python'
; Sets $PythonFound = "1" or "0" and $PythonExe to the path if found.
; ---------------------------------------------------------------------------
Var PythonFound
Var PythonExe

Function DetectPython
    StrCpy $PythonFound "0"
    StrCpy $PythonExe ""

    ; Try the 'py' launcher first (installed by python.org installers)
    nsExec::ExecToStack 'py -3 -c "import sys; print(sys.executable)"'
    Pop $0  ; return code
    Pop $1  ; output
    ${If} $0 == 0
        StrCpy $PythonFound "1"
        StrCpy $PythonExe "py -3"
        Return
    ${EndIf}

    ; Fall back to 'python' on PATH
    nsExec::ExecToStack 'python -c "import sys; print(sys.executable)"'
    Pop $0
    Pop $1
    ${If} $0 == 0
        StrCpy $PythonFound "1"
        StrCpy $PythonExe "python"
        Return
    ${EndIf}
FunctionEnd

; ---------------------------------------------------------------------------
; Section: Install Python (only runs if Python was not detected)
; ---------------------------------------------------------------------------
Section "Python 3 Runtime" SecPython

    Call DetectPython
    ${If} $PythonFound == "1"
        DetailPrint "Python already installed - skipping Python installation."
        Goto python_done
    ${EndIf}

    DetailPrint "Python not found. Downloading Python ${PYTHON_VERSION} (64-bit)..."
    SetOutPath "$TEMP"

    ; Use PowerShell (built into Windows) instead of NSISdl - it handles
    ; HTTPS/TLS1.2 and redirects reliably regardless of NSIS build/locale.
    DetailPrint "  Downloading: ${PYTHON_URL}"
    nsExec::ExecToLog 'powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; try { Invoke-WebRequest -Uri $\'${PYTHON_URL}$\' -OutFile $\'$TEMP\${PYTHON_INSTALLER}$\' -UseBasicParsing } catch { Write-Host $$_.Exception.Message; exit 1 }"'
    Pop $0

    IfFileExists "$TEMP\${PYTHON_INSTALLER}" python_downloaded 0

    DetailPrint "  First attempt failed, retrying once..."
    nsExec::ExecToLog 'powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; try { Invoke-WebRequest -Uri $\'${PYTHON_URL}$\' -OutFile $\'$TEMP\${PYTHON_INSTALLER}$\' -UseBasicParsing } catch { Write-Host $$_.Exception.Message; exit 1 }"'
    Pop $0

    IfFileExists "$TEMP\${PYTHON_INSTALLER}" python_downloaded 0

    ; ---- Both download attempts failed ----
    MessageBox MB_ICONEXCLAMATION|MB_YESNO \
        "Could not download the Python installer automatically (no internet access, proxy, or firewall block).$\r$\n$\r$\nDo you want to continue the setup anyway?$\r$\n$\r$\nIf you continue, please install Python 3.10+ manually from:$\r$\nhttps://www.python.org/downloads/$\r$\n(check 'Add python.exe to PATH' during install), then re-run this setup to finish installing dependencies and OpenNEC." \
        IDYES python_done IDNO 0
    Abort

    python_downloaded:
    DetailPrint "Installing Python ${PYTHON_VERSION} silently (this may take a minute)..."
    ; PrependPath=1 adds Python + Scripts to PATH for all users
    ExecWait '"$TEMP\${PYTHON_INSTALLER}" /quiet InstallAllUsers=1 PrependPath=1 Include_test=0 Include_launcher=1' $0
    ${If} $0 != 0
        MessageBox MB_ICONEXCLAMATION "Python installation returned exit code $0.$\r$\n$\r$\nSetup will continue, but if Python wasn't installed correctly please install it manually from https://www.python.org/downloads/ and re-run this setup afterwards."
    ${EndIf}
    Delete "$TEMP\${PYTHON_INSTALLER}"

    ; Refresh detection after install
    Call DetectPython
    ${If} $PythonFound != "1"
        ; PATH may need a new shell session to refresh - try the default install path
        StrCpy $PythonExe "$PROGRAMFILES64\Python312\python.exe"
        IfFileExists "$PythonExe" 0 +2
            StrCpy $PythonFound "1"
    ${EndIf}

    python_done:
SectionEnd

; ---------------------------------------------------------------------------
; Section: Application files
; ---------------------------------------------------------------------------
Section "Application Files" SecApp

    SetOutPath "$INSTDIR"

    ; -----------------------------------------------------------------
    ; nec2_length_optimizer.py is intentionally NOT embedded/compressed
    ; into this installer.  It is shipped as a loose .py file in the
    ; SAME FOLDER as Setup.exe ($EXEDIR) and is MOVED into $INSTDIR here.
    ;
    ; Distribution layout expected:
    ;   SomeFolder\
    ;     NEC2_Length_Optimizer_Setup.exe
    ;     nec2_length_optimizer.py
    ; -----------------------------------------------------------------
    IfFileExists "$EXEDIR\${APP_EXE_SCRIPT}" 0 script_not_at_exedir
        ; Try a fast rename (move) first; fall back to copy+delete if
        ; $EXEDIR and $INSTDIR are on different volumes (Rename fails
        ; across volumes and sets the error flag).
        ClearErrors
        Rename "$EXEDIR\${APP_EXE_SCRIPT}" "$INSTDIR\${APP_EXE_SCRIPT}"
        IfErrors 0 script_moved
            CopyFiles /SILENT "$EXEDIR\${APP_EXE_SCRIPT}" "$INSTDIR\${APP_EXE_SCRIPT}"
            Delete "$EXEDIR\${APP_EXE_SCRIPT}"
        script_moved:
        Goto script_done

    script_not_at_exedir:
        ; Not found beside Setup.exe -- maybe this is a repair/re-run and
        ; it was already moved into place by a previous run.
        IfFileExists "$INSTDIR\${APP_EXE_SCRIPT}" script_done 0
        MessageBox MB_ICONEXCLAMATION "${APP_EXE_SCRIPT} was not found next to this installer ($EXEDIR) and is not already installed.$\r$\n$\r$\nPlace ${APP_EXE_SCRIPT} in the same folder as Setup.exe and re-run, or copy it manually into:$\r$\n$INSTDIR"

    script_done:

    File "payload\run_gui.bat"
    File "payload\post_install_setup.py"
    File "assets\app.ico"
    File "assets\LICENSE.txt"

SectionEnd

; ---------------------------------------------------------------------------
; Section: OpenNEC (onec.exe) engine - statically-linked, bundled binary
;
; Official OpenNEC v2.1.0+ Windows builds are MinGW-w64/GCC 15.x/16.x and
; refuse to start with "missing libwinpthread-1.dll" / "missing
; libgcc_s_seh-1.dll" / "missing libstdc++-6.dll", or:
;     "The procedure entry point clock_gettime64 could not be located in
;      the dynamic link library ...\libstdc++-6.dll"
; This last one is an unresolved upstream MinGW-w64/GCC 15.x/16.x toolchain
; bug (msys2/MINGW-packages#24355, #27465; niXman/mingw-builds-binaries#112)
; - no runtime DLL "fixes" it, because clock_gettime64 simply isn't exported
; by any current MinGW-w64 GCC 15.x/16.x libstdc++-6.dll / libgcc_s_seh-1.dll.
;
; Fix: payload\bin\onec.exe is a STATICALLY-LINKED build of OpenNEC built
; from source (BACKEND=original; -static -static-libgcc -static-libstdc++
; -lwinpthread). It has NO MinGW runtime DLL dependencies at all - only
; KERNEL32.dll and msvcrt.dll, both always present on Windows. This
; completely avoids the issue above, with zero internet access required.
;
; This section copies that binary into every location onec.exe might end
; up in, and additionally keeps a backup copy (onec_bundled.exe) so
; post_install_setup.py's repair_existing_engine() can restore it later
; if an optional official-release "upgrade" turns out to be broken:
;   - $INSTDIR\nec2c\onec.exe / onec_bundled.exe  (primary engine location)
;   - C:\Program Files\OpenNEC\onec.exe           (hard-coded search path)
;   - C:\Program Files (x86)\OpenNEC\onec.exe     (hard-coded search path)
;
; Fallback runtime DLLs (v1.0.5): the three files below are also dropped
; into every one of the locations above:
;   - libwinpthread-1.dll
;   - libgcc_s_seh-1.dll
;   - libstdc++-6.dll
; The bundled static onec.exe above does not use these at all (it has no
; DLL dependencies whatsoever). They exist purely so that IF
; post_install_setup.py's optional official-release upgrade later drops a
; dynamically-linked onec.exe into nec2c\ (or Program Files\OpenNEC\),
; that binary finds libwinpthread-1.dll / libgcc_s_seh-1.dll /
; libstdc++-6.dll sitting right next to it (Windows searches the EXE's
; own directory first), instead of failing with "...libwinpthread-1.dll
; was not found...". This does not address the separate clock_gettime64
; issue (verify_onec()/repair_existing_engine() still handle that), but it
; does fix the more common plain "missing libwinpthread-1.dll" case.
;
; This section runs unconditionally (no internet required) and also repairs
; previously-broken installs: simply re-running this installer drops a
; known-good onec.exe (and these runtime DLLs) into place.
; ---------------------------------------------------------------------------
Section "OpenNEC Engine (onec.exe)" SecEngine

    DetailPrint "Installing OpenNEC engine (onec.exe, statically linked)..."

    CreateDirectory "$INSTDIR\nec2c"
    SetOutPath "$INSTDIR\nec2c"
    File "/oname=onec.exe" "payload\bin\onec.exe"
    File "/oname=onec_bundled.exe" "payload\bin\onec.exe"
    File "payload\bin\libwinpthread-1.dll"
    File "payload\bin\libgcc_s_seh-1.dll"
    File "payload\bin\libstdc++-6.dll"

    CreateDirectory "$PROGRAMFILES64\OpenNEC"
    SetOutPath "$PROGRAMFILES64\OpenNEC"
    File "/oname=onec.exe" "payload\bin\onec.exe"
    File "payload\bin\libwinpthread-1.dll"
    File "payload\bin\libgcc_s_seh-1.dll"
    File "payload\bin\libstdc++-6.dll"

    CreateDirectory "$PROGRAMFILES32\OpenNEC"
    SetOutPath "$PROGRAMFILES32\OpenNEC"
    File "/oname=onec.exe" "payload\bin\onec.exe"
    File "payload\bin\libwinpthread-1.dll"
    File "payload\bin\libgcc_s_seh-1.dll"
    File "payload\bin\libstdc++-6.dll"

    SetOutPath "$INSTDIR"

SectionEnd

; ---------------------------------------------------------------------------
; Section: Python dependencies + OpenNEC (post-install setup)
; ---------------------------------------------------------------------------
Section "Dependencies & OpenNEC" SecDeps

    Call DetectPython
    ${If} $PythonFound != "1"
        DetailPrint "Python is not available - skipping Python package setup."
        DetailPrint "Install Python manually, then re-run this setup to finish (or run post_install_setup.py yourself)."
        MessageBox MB_ICONEXCLAMATION "Python could not be found on this system, so Python packages (numpy, matplotlib, etc.) were not installed.$\r$\n$\r$\nThe OpenNEC engine (onec.exe) has already been installed and is ready to use.$\r$\n$\r$\nAfter installing Python 3.10+ manually, re-run this setup, or run:$\r$\n  python $\"$INSTDIR\post_install_setup.py$\" $\"$INSTDIR$\""
        Goto deps_done
    ${EndIf}

    DetailPrint "Installing required Python packages..."
    DetailPrint "(numpy, matplotlib, tabulate, colorama, reportlab)"
    DetailPrint ""
    DetailPrint "NOTE: the OpenNEC engine (onec.exe, statically linked, no DLLs"
    DetailPrint "      required) has already been installed by this setup. This"
    DetailPrint "      step will also check whether a newer official OpenNEC"
    DetailPrint "      release works on this system and use it if so."

    ; Use 'cmd /c' so we can use the 'py -3' launcher (two tokens) uniformly
    nsExec::ExecToLog 'cmd /c $PythonExe "$INSTDIR\post_install_setup.py" "$INSTDIR"'
    Pop $0
    ${If} $0 != 0
        MessageBox MB_ICONEXCLAMATION "Some optional setup steps (Python packages, or checking for a newer OpenNEC release) did not complete successfully.$\r$\n$\r$\nYou can re-run:$\r$\n  $PythonExe $\"$INSTDIR\post_install_setup.py$\" $\"$INSTDIR$\"$\r$\nlater.$\r$\n$\r$\nThe bundled OpenNEC engine (onec.exe, statically linked) has already$\r$\nbeen placed in:$\r$\n$INSTDIR\nec2c  and  $PROGRAMFILES64\OpenNEC$\r$\nand is ready to use regardless."
    ${EndIf}

    deps_done:
SectionEnd

; ---------------------------------------------------------------------------
; Section: Shortcuts
; ---------------------------------------------------------------------------
Section "Shortcuts" SecShortcuts

    CreateDirectory "$SMPROGRAMS\NEC2 Antenna Length Optimizer"
    CreateShortCut "$SMPROGRAMS\NEC2 Antenna Length Optimizer\NEC2 Antenna Length Optimizer.lnk" \
        "$INSTDIR\${APP_LAUNCHER}" "" "$INSTDIR\app.ico" 0
    CreateShortCut "$SMPROGRAMS\NEC2 Antenna Length Optimizer\Uninstall.lnk" \
        "$INSTDIR\Uninstall.exe"

    ; Desktop shortcut (icon to run nec2_length_optimizer.py --gui)
    CreateShortCut "$DESKTOP\NEC2 Antenna Length Optimizer.lnk" \
        "$INSTDIR\${APP_LAUNCHER}" "" "$INSTDIR\app.ico" 0

SectionEnd

; ---------------------------------------------------------------------------
; Section: Uninstaller registration
; ---------------------------------------------------------------------------
Section -FinishSection

    WriteUninstaller "$INSTDIR\Uninstall.exe"

    WriteRegStr HKLM "${UNINST_KEY}" "DisplayName" "${APP_NAME}"
    WriteRegStr HKLM "${UNINST_KEY}" "UninstallString" "$INSTDIR\Uninstall.exe"
    WriteRegStr HKLM "${UNINST_KEY}" "InstallLocation" "$INSTDIR"
    WriteRegStr HKLM "${UNINST_KEY}" "DisplayIcon" "$INSTDIR\app.ico"
    WriteRegStr HKLM "${UNINST_KEY}" "Publisher" "${APP_PUBLISHER}"
    WriteRegStr HKLM "${UNINST_KEY}" "DisplayVersion" "${APP_VERSION}"
    WriteRegDWORD HKLM "${UNINST_KEY}" "NoModify" 1
    WriteRegDWORD HKLM "${UNINST_KEY}" "NoRepair" 1

    ${GetSize} "$INSTDIR" "/S=0K" $0 $1 $2
    IntFmt $0 "0x%08X" $0
    WriteRegDWORD HKLM "${UNINST_KEY}" "EstimatedSize" "$0"

SectionEnd

; ---------------------------------------------------------------------------
; Uninstaller
; ---------------------------------------------------------------------------
Section "Uninstall"

    Delete "$INSTDIR\${APP_EXE_SCRIPT}"
    Delete "$INSTDIR\${APP_LAUNCHER}"
    Delete "$INSTDIR\post_install_setup.py"
    Delete "$INSTDIR\set_nec2c_env.bat"
    Delete "$INSTDIR\app.ico"
    Delete "$INSTDIR\LICENSE.txt"
    Delete "$INSTDIR\Uninstall.exe"
    RMDir /r "$INSTDIR\nec2c"
    RMDir /r "$INSTDIR\__pycache__"

    ; Remove the OpenNEC copy placed in Program Files\OpenNEC (and the
    ; (x86) variant) so the script's hard-coded search path doesn't keep
    ; finding a leftover binary after uninstall.
    Delete "$PROGRAMFILES64\OpenNEC\onec.exe"
    Delete "$PROGRAMFILES64\OpenNEC\*.dll"
    RMDir "$PROGRAMFILES64\OpenNEC"
    Delete "$PROGRAMFILES32\OpenNEC\onec.exe"
    Delete "$PROGRAMFILES32\OpenNEC\*.dll"
    RMDir "$PROGRAMFILES32\OpenNEC"

    ; If the user left generated reports/plots/CSVs in the install dir,
    ; ask before wiping the whole folder; otherwise just remove it.
    FindFirst $0 $1 "$INSTDIR\*.*"
    StrCpy $2 "0"
    leftover_loop:
        StrCmp $1 "" leftover_done
        StrCmp $1 "." leftover_next
        StrCmp $1 ".." leftover_next
        StrCpy $2 "1"
        Goto leftover_done
    leftover_next:
        FindNext $0 $1
        Goto leftover_loop
    leftover_done:
        FindClose $0

    ${If} $2 == "1"
        MessageBox MB_ICONQUESTION|MB_YESNO \
            "The folder$\r$\n$INSTDIR$\r$\nstill contains files (e.g. generated reports, plots, or CSVs).$\r$\n$\r$\nDelete this folder and all its contents?" \
            IDYES remove_instdir IDNO keep_instdir
        remove_instdir:
            RMDir /r "$INSTDIR"
        keep_instdir:
    ${Else}
        RMDir "$INSTDIR"
    ${EndIf}

    Delete "$DESKTOP\NEC2 Antenna Length Optimizer.lnk"
    Delete "$SMPROGRAMS\NEC2 Antenna Length Optimizer\NEC2 Antenna Length Optimizer.lnk"
    Delete "$SMPROGRAMS\NEC2 Antenna Length Optimizer\Uninstall.lnk"
    RMDir "$SMPROGRAMS\NEC2 Antenna Length Optimizer"

    DeleteRegKey HKLM "${UNINST_KEY}"

    MessageBox MB_ICONINFORMATION|MB_OK "NEC2 Antenna Length Optimizer has been removed from your computer.$\r$\n$\r$\nNote: Python and its packages (numpy, matplotlib, etc.) were left installed, as they may be used by other programs. Uninstall Python separately via 'Add or Remove Programs' if no longer needed."

SectionEnd
